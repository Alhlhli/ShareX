# ShareX

[![GitHub Workflow Status](https://img.shields.io/github/actions/workflow/status/ShareX/ShareX/build.yml?branch=develop&label=Build&cacheSeconds=3600)](https://github.com/ShareX/ShareX/actions/workflows/build.yml)
[![License](https://img.shields.io/github/license/ShareX/ShareX?label=License&color=brightgreen&cacheSeconds=3600)](./LICENSE.txt)
[![Release](https://img.shields.io/github/v/release/ShareX/ShareX?label=Release&color=brightgreen&cacheSeconds=3600)](https://github.com/ShareX/ShareX/releases/latest)
[![Downloads](https://img.shields.io/github/downloads/ShareX/ShareX/total?label=Downloads&cacheSeconds=3600)](https://getsharex.com/downloads/)
[![Discord](https://img.shields.io/discord/194170124859736065?label=Discord&cacheSeconds=3600)](https://discord.gg/ShareX)
[![Twitter](https://img.shields.io/twitter/follow/ShareX?cacheSeconds=3600)](https://twitter.com/intent/follow?screen_name=ShareX)

[![Screenshot](https://getsharex.com/img/ShareX_Screenshot.png)](https://getsharex.com)

### For further information check [getsharex.com](https://getsharex.com)
